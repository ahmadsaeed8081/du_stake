import React, { useEffect, useState } from "react";

const Footer = () => {
  return (
    <div className="footer-comp flex flex-col">
      <div className="wrapWidth wrap flex jc aic"></div>
    </div>
  );
};

export default Footer;
